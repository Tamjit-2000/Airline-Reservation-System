package airline.reservation.system;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

import airline.reservation.system.AirlineConnection;

public class airline_reservation_system {

	public static void main(String[] args) throws NumberFormatException, IOException, ClassNotFoundException, SQLException, ParseException {
		// TODO Auto-generated method stub
		 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		 PreparedStatement	ps=null;
		 Connection conn=null;
	        
	        System.out.println("");
	        System.out.println("=====================  WELCOME TO Airline Reservation ================================");
	        System.out.println("**************************************************************************************");   
	        System.out.println("\t\t 1 --> CUSTOMER");
	        System.out.println("\t\t 2 --> ADMIN");
	        System.out.println("");
	        System.out.println("**************************************************************************************");
	        System.out.println("Enter your choice:");
	        int choice=Integer.parseInt(br.readLine());
	        
	        
	        if(choice==1)
	        {
	        	
	        	 System.out.print("\t\t 1 --> Resistration \n");
	        	 System.out.print("\t\t 2 --> Login");
	        	 System.out.println("");
	        	 System.out.println("**************************************************************************************");
	 	        System.out.println("Enter your choice:");
	 	        int cho=Integer.parseInt(br.readLine());
	            
	 	       switch(cho)
               {
                case 1:
	            	System.out.println("Enter customer's Id:");
	            	 int cusid=Integer.parseInt(br.readLine());
	            	 
	         		System.out.println("Enter customer's Name:");
					String name = br.readLine();

					System.out.println("Enter customer's username:");
					String uname = br.readLine();

					System.out.println("Enter customer's Password:");
					String cuspassword = br.readLine();
					
					System.out.println("Re-enter account password: ");
					
					String repassword = br.readLine();
					
				

					System.out.println("Enter email id:");
					String email = br.readLine();

					System.out.println("Enter address: ");
					String address = br.readLine();
					
					System.out.println("Date of Birth:(dd/MM/YYYY)");
					String dob = br.readLine();

					System.out.println("Enter Adhar no: ");
					String adhar_no = br.readLine();
					
					conn=AirlineConnection.getConnection();
			        ps = conn.prepareStatement("insert into customer values(?,?,?,?,?,?,?,?)");
					ps.setInt(1, cusid);
					ps.setString(2, name);
					ps.setString(3, uname);
					ps.setString(4, cuspassword);
					ps.setString(5, email);
					ps.setString(6, address);

					SimpleDateFormat format = new SimpleDateFormat("dd/MM/YYYY");
					java.util.Date utilDate = format.parse(dob);
					java.sql.Date date = new java.sql.Date(utilDate.getTime());
					ps.setDate(7, date);
					ps.setString(8, adhar_no);
					

					if (ps.executeUpdate() > 0) {
						System.out.println("==============================================================================");
						System.out.println("Account created successfully!!");
						System.out.println("==============================================================================");

						
					}
					
					
					
					

                case 2:
                {
	            System.out.println("===========================    LOGIN DETAILS  ================================");
	            System.out.println("******************************************************************************");
	            
	            System.out.print("\t Enter your username:");
	            String userName=br.readLine();
	            System.out.print("\t Enter your password:");
	            String userPassword=br.readLine();
	            try
	            {
	            	Connection conn1=AirlineConnection.getConnection();
	             ps=conn1.prepareStatement("select cuspassword from customer where cususername=?");
	            ps.setString(1, userName);
	            ResultSet result=ps.executeQuery();
	            String password=null;
	            boolean login=false;
	            while(result.next())
	            {
	                password=result.getString("cuspassword");
	                login=true;
	            }
	            
	            if(password.equals(userPassword))
	            {
	                
	                System.out.println("===========================   Login successful ================================");
	                System.out.println("*******************************************************************************");
	                System.out.println("============================== WELCOME "+  userName.toUpperCase()  +" ===============================");
	                

	                String status="Y";
	                do
	                {
	                    
	                System.out.println("\t\t  1 --> Search Flight");
	                System.out.println("\t\t  2 --> Seat Booking");
	                System.out.println("\t\t  3 --> Change Password");
	                System.out.println("\t\t  4 --> Exit/Logout");
	                System.out.println("******************************************************************************");
	                System.out.print("Enter your choice:");
	                int operationCode=Integer.parseInt(br.readLine());
	                
	                switch(operationCode)
	                {
	                 case 1:System.out.println("\t Enter the Flight Date:");
	                        String Date=br.readLine();
	                        
	                        System.out.print("\t Enter the Flight Time: ");
	                        String Time=br.readLine();
                       	 System.out.println("");
	                        Connection conn2=AirlineConnection.getConnection();
	                        PreparedStatement stmt = conn2.prepareStatement("SELECT * FROM flight WHERE date  = ? AND 	time = ?");
	                        stmt.setString(1, Date);
	                        stmt.setString(2, Time);

	                        ResultSet rs = stmt.executeQuery();
	                        


	                        while (rs.next()) {
	                        	
	                        	System.out.printf("\t\t\t %-10s %-10s %-10s %-10s %-10s %-20s \n","flight_no","flight_name","from_city","to_city","date","time");
	                        	 System.out.println("==============================================================================================================================");
	                        	 System.out.printf("\t\t\t %-10s %-10s %-10s %-10s %-10s %-20s \n",rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)); 	                        	
	                            
	                        	 System.out.println("");
	                        
	                        	
	                        }
	                        
	                        System.out.println("Do you want to continue?(Y/N)");
							status = br.readLine();

							if (status.equals("n") || status.equals("N")) {
								login = false;
							}
							break;

	                       

	                 case 2:
	                	 Scanner sc=new Scanner(System.in);
	                	 System.out.println("******************************************************************************\n"); 
	                	 System.out.print("\t 1  view available seats \n");
	                	 System.out.print("\t 2  book a seat\n");
	     
	                	 System.out.println("******************************************************************************");
	                	 int ch = sc.nextInt();
	                	  if(ch==1)
	 	                {
	                     
	                    	 Connection conn3=AirlineConnection.getConnection();
	                    	 Statement st = conn3.createStatement();
	                    	  ResultSet re = st.executeQuery("SELECT seat_number FROM reservations");
		                       
		                        ArrayList<String> reservedSeats = new ArrayList<>();
		                        
		                        while (re.next()) {
		                             reservedSeats.add(re.getString("seat_number"));
		                         }
		                        System.out.println("\nAvailable seats:");
		                         for (int i = 1; i <= 10; i++) {
		                             for (char j = 'A'; j <= 'F'; j++) {
		                                 String seatNumber = i + String.valueOf(j);
		                                 if (reservedSeats.contains(seatNumber)) {
		                                     System.out.print("X ");
		                                 } else {
		                                     System.out.print(seatNumber + " ");
		                                 }
		                                 
		                             }
		                             System.out.println();
	 	                }
		                       
									
	 	                }
	                	  else if(ch==2) {
	                        
	                       	 System.out.print("Enter id: ");
	                         int id = sc.nextInt();
	                    	 
	                    	 System.out.print("Enter Flight name: ");
	                         String fname = sc.next();
	                         
	                         System.out.print("Enter Seat Number: ");
	                         String seat_number = sc.next().toUpperCase();
	                         
	                         System.out.println("=========================================================================");
	                         Connection conn4=AirlineConnection.getConnection();
	                         PreparedStatement pr=conn4.prepareStatement("insert into reservations values(?,?,?)");
	                        pr.setInt(1, id);
	                         pr.setString(2, fname);
	                         pr.setString(3, seat_number);
	                         
	                     	if(pr.executeUpdate()>0) {
	        					
	        					System.out.println("Seat Book");
	        					
	        					System.out.println("==============================================================================");
	        					System.out.println("Have a nice day!!");
	        					System.out.println("==============================================================================");
	        				}
	        				else {
	        					System.out.println("Seat not Book.....!!!!!");
	        					
	        				}
	                     	
	                     	 System.out.println("=========================================================================");
	                	  } 
	                	  System.out.println("Do you want to continue?(Y/N)");
							status = br.readLine();

							if (status.equals("n") || status.equals("N")) {
								login = false;
							}
	                	  break;
	                	 
	                 case 3: 
	                	 System.out.println("Enter the old password:");
							String oldPassword = br.readLine();

							System.out.println("Enter the new password:");
							String newPassword = br.readLine();

							System.out.println("Re-enter the new password:");
							String rePassword = br.readLine();
							Connection conn5=AirlineConnection.getConnection();
							ps = conn5.prepareStatement("select * from customer where cususername=?");
							ps.setString(1, userName);

							result = ps.executeQuery();
							String existingPassword = null;
							while (result.next()) {
								existingPassword = result.getString("cuspassword");

							}

							if (existingPassword.equals(oldPassword)) {
								if (newPassword.equals(rePassword)) {
									Connection conn6=AirlineConnection.getConnection();
									ps = conn6.prepareStatement("update customer set cuspassword=? where cususername=?");
									ps.setString(1, newPassword);
									ps.setString(2, userName);

									if (ps.executeUpdate() > 0) {
										System.out.println("==============================================================================");
										System.out.println("Password changed successfully!!");
										System.out.println("==============================================================================");

									} else {
										System.out.println("==============================================================================");
										System.out.println("Problem in password changed!!");
										System.out.println("==============================================================================");

									}

								} else {
									System.out.println("==============================================================================");
									System.out.println("New password and retype password must be same!!");
									System.out.println("==============================================================================");

								}
							} else {
								System.out.println("==============================================================================");
								System.out.println("Old password is wrong!!");
								System.out.println("==============================================================================");

							}
							System.out.println("Do you want to continue?(Y/N)");
							status = br.readLine();

							if (status.equals("n") || status.equals("N")) {
								login = false;
							}
							break;
							
	                 case 4:
							login = false;
							break;

						default:
							System.out.println("!!!!.....Wrong Choice.....!!!!");
							break;

	                     }
	                
	                	       
	                   
	                     
	                        
	                       
	                
	               
	                
	            } while(login); 
	                System.out.println("==============================================================================");
	                System.out.println("Bye. Have a nice day!!");
	                System.out.println("==============================================================================");

	    
	                
	                
	            }
	            else
	            {
	                System.out.println("==============================================================================");
	                System.out.println("================================  Wrong password  ============================");
	                System.out.println("==============================================================================");
	            }
	            }
	            catch(Exception e)
	            {
	                System.out.println(e);
	                System.out.println("==============================================================================");
	                System.out.println("===========================  Wrong username/password  ========================");
	                System.out.println("==============================================================================");
	        
	            }
	            
                }
               }
	        
	        }  

	
	        
	        else if (choice == 2) {

				System.out.println("==============================================================================");
				System.out.println("===========================    LOGIN DETAILS  ================================");
				System.out.println("==============================================================================");

				System.out.print("\t Enter your username:");
				String userName = br.readLine();
				System.out.print("\t Enter your password:");
				String userPassword = br.readLine();

			     conn=AirlineConnection.getConnection();
			 ps = conn.prepareStatement("select * from admin where username=?");
				ps.setString(1, userName);
				ResultSet result = ps.executeQuery();
				String password = null;
				boolean login = false;
				while (result.next()) {
					password = result.getString("password");
					login = true;
				}

				if (password.equals(userPassword)) {

					String status = "y";
					System.out.println("==============================================================================");
					System.out.println("=============================   WELCOME ADMIN    =============================");
					System.out.println("==============================================================================");

					do {
						System.out.println("==============================================================================");
						System.out.println("");
						System.out.println("\t\t  1 --> Add Flight");
						System.out.println("\t\t  2 --> Close Account");
						System.out.println("\t\t  3 --> View CustomerDetails");
						System.out.println("\t\t  4 --> Change Password");
						System.out.println("\t\t  5 --> Exit/Logout");
						System.out.println("==============================================================================");
						System.out.println("");
						
						System.out.println("Enter your choice:");
						int operation = Integer.parseInt(br.readLine());

						switch (operation) {
						case 1:
							System.out.println("Enter Flight no :");
							String flight_no = br.readLine();

							System.out.println("Enter Flight name:");
							String flight_name = br.readLine();

							System.out.println("Enter from city:");
							String from_city = br.readLine();
							
							System.out.println("Enter To city:");
							String to_city = br.readLine();

							System.out.println("Enter Date (dd/MM/YYYY)");
							String flightdate = br.readLine();

							System.out.println("Enter Flight Time :");
							String time = br.readLine();

							System.out.println("Enter Aireport Name:");
							String aireport_name =br.readLine();

							System.out.println("Enter Ticket price: ");
							String ticket_price = br.readLine();

							
							ps = conn.prepareStatement("insert into flight values(?,?,?,?,?,?,?,?)");
							ps.setString(1, flight_no);
							ps.setString(2, flight_name);
							ps.setString(3, from_city);
							ps.setString(4, to_city);
							SimpleDateFormat format = new SimpleDateFormat("dd/MM/YYYY");
							java.util.Date utilDate = format.parse(flightdate);
							java.sql.Date date = new java.sql.Date(utilDate.getTime());
							ps.setDate(5, date);
							ps.setString(6, time);
							ps.setString(7, aireport_name);
							ps.setString(8, ticket_price);
							
							if (ps.executeUpdate() > 0) {
								System.out.println("==============================================================================");
								System.out.println("**********************Flight Added successfully...!!!*************************");
								System.out.println("==============================================================================");

							}

							System.out.println("Do you want to continue?(Y/N)");
							status = br.readLine();

							if (status.equals("n") || status.equals("N")) {
								login = false;
							}
							break;

						case 2:
							System.out.println("Enter customer id:");
							long customerId = Long.parseLong(br.readLine());

							ps = conn.prepareStatement("delete from customer where cu_id =?");
							ps.setLong(1, customerId);

							if (ps.executeUpdate() > 0) {
								System.out.println("==============================================================================");
								System.out.println("*********************Account closed successfully....!!************************");
								System.out.println("==============================================================================");

							} else {
								System.out.println("==============================================================================");
								System.out.println("*********************Problem in account closing.....!!************************");
								System.out.println("==============================================================================");

							}
							System.out.println("Do you want to continue?(Y/N)");
							status = br.readLine();

							if (status.equals("n") || status.equals("N")) {
								login = false;
							}
							break;
						case 3:
							System.out.println("\t Enter the customer Id:");
	                        String cusid=br.readLine();
	                     
                       	 System.out.println("");
	                        Connection conn2=AirlineConnection.getConnection();
	                        PreparedStatement stmt = conn2.prepareStatement("SELECT * FROM customer WHERE cu_id  = ?" );
	                        stmt.setString(1, cusid);
	                

	                        ResultSet rs = stmt.executeQuery();
	                        


	                        while (rs.next()) {
	                        	
	                        	System.out.printf("\t\t\t %-10s %-20 %-10s %-20s %-25s %-15s %-20s %-20s \n","cu_id","name","cususername","cuspassword","email","Address","bod","adhar_no");
	                        	 System.out.println("\\t\\t\\t==============================================================================================================================");
	                        	 System.out.printf("\t\t\t %-10s %-20 %-10s %-20s %-25s %-15s %-20s %-20s \n",rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8)); 	                        	
	                            
	                        	 System.out.println("");
	                        
	                        	
	                        }
	                        
	                        System.out.println("Do you want to continue?(Y/N)");
							status = br.readLine();

							if (status.equals("n") || status.equals("N")) {
								login = false;
							}
							break;

	                       

						case 4:
							System.out.println("Enter the old password:");
							String oldPassword = br.readLine();

							System.out.println("Enter the new password:");
							String newPassword = br.readLine();

							System.out.println("Re-enter the new password:");
							String rePassword = br.readLine();

							ps = conn.prepareStatement("select * from admin where username=?");
							ps.setString(1, userName);

							result = ps.executeQuery();
							String existingPassword = null;
							while (result.next()) {
								existingPassword = result.getString("password");

							}

							if (existingPassword.equals(oldPassword)) {
								if (newPassword.equals(rePassword)) {
									ps = conn.prepareStatement("update admin set password=? where username=?");
									ps.setString(1, newPassword);
									ps.setString(2, userName);

									if (ps.executeUpdate() > 0) {
										System.out.println(
												"==============================================================================");
										System.out.println("Password changed successfully!!");
										System.out.println(
												"==============================================================================");

									} else {
										System.out.println(
												"==============================================================================");
										System.out.println("Problem in password changed!!");
										System.out.println(
												"==============================================================================");

									}

								} else {
									System.out.println(
											"==============================================================================");
									System.out.println("New password and retype password must be same!!");
									System.out.println(
											"==============================================================================");

								}
							} else {
								System.out.println(
										"==============================================================================");
								System.out.println("Old password is wrong!!");
								System.out.println(
										"==============================================================================");

							}
							System.out.println("Do you want to continue?(Y/N)");
							status = br.readLine();

							if (status.equals("n") || status.equals("N")) {
								login = false;
							}
							break;

						case 5:
							login = false;
							break;

						default:
							System.out.println("Wrong Choice!!");
							break;

						}

					} while (login);
					
					System.out.println("==============================================================================");
					System.out.println("Bye. Have a nice day!!");
					System.out.println("==============================================================================");
					

				} else {
					System.out.println("Enter a valid input!!");
				}
			}
		}


}
